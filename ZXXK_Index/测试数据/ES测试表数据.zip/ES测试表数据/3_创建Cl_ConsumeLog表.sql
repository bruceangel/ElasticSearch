--������
CREATE TABLE [dbo].[Cl_ConsumeLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ChannelID] [int] NULL,
	[InfoID] [int] NULL,
	[Title] [nvarchar](250) NULL,
	[UserID] [int] NULL,
	[UserName] [nvarchar](50) NULL,
	[SchoolUserID] [int] NULL,
	[ConsumePoint] [decimal](8, 2) NULL,
	[ConsumeAdvPoint] [int] NULL,
	[ConsumeMoney] [decimal](8, 2) NULL,
	[ConsumeTime] [smalldatetime] NULL,
	[UserDownIP] [nvarchar](50) NULL,
	[Editor] [nvarchar](50) NULL,
	[Censor] [nvarchar](50) NULL,
	[IsBoutique] [int] NULL,
	[SoftTypeID] [int] NULL,
	[RequestSource] [int] NULL,
	[PlatForm] [int] NULL,
	[ConsumeType] [int] NULL,
	[IpArea] [nvarchar](50) NULL,
	[DownInterface] [int] NULL,
 CONSTRAINT [PK_Cl_ConsumeLog] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ѧ��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ChannelID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'InfoID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϱ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'Title'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����û�ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'UserID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����û���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'UserName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��УͨѧУID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'SchoolUserID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������ͨ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ConsumePoint'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���Ѹ߼���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ConsumeAdvPoint'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���Ѵ�ֵ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ConsumeMoney'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ConsumeTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�û�����IP' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'UserDownIP'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����ϴ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'Editor'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'Censor'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ�Ʒ��0=�Ǿ�Ʒ��1=��Ʒ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'IsBoutique'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'SoftTypeID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������Դ 1=ѧ������2=Mվ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'RequestSource'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ƽ̨���� ��1=PC��2=ANDROID��3=IOS��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'PlatForm'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������ͣ�1=��ֵ��2=�߼��㣻3=��ͨ�㣻4=��ѣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'ConsumeType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'IpArea'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ؽӿڣ�1=��Уͨ��2=��ѧͨ��3=��Ƶͨ��4=��ͨ�Ƶ㣬5=��ͨ���죬6=��IP�߶���Уͨ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_ConsumeLog', @level2type=N'COLUMN',@level2name=N'DownInterface'
GO


