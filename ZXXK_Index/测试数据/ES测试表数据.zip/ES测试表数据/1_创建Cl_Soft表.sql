--�������ϱ�
CREATE TABLE [dbo].[Cl_Soft](
	[SoftID] [int] IDENTITY(1,1) NOT FOR REPLICATION NOT NULL,
	[InfoGuid] [uniqueidentifier] NOT NULL,
	[CollectID] [int] NOT NULL,
	[ChannelID] [int] NOT NULL,
	[ClassID] [int] NOT NULL,
	[ChapterID] [int] NOT NULL,
	[NodeID] [int] NOT NULL,
	[WholeID] [int] NULL,
	[SpecialID] [int] NOT NULL,
	[FeatureID] [int] NULL,
	[DepartmentID] [int] NULL,
	[GradeID] [int] NULL,
	[Prefixion] [nvarchar](20) NULL,
	[SoftName] [nvarchar](255) NOT NULL,
	[FontColor] [nvarchar](7) NULL,
	[FontType] [int] NOT NULL,
	[VersionID] [int] NULL,
	[SoftVersion] [nvarchar](100) NULL,
	[Keyword] [nvarchar](255) NOT NULL,
	[AreaID] [int] NOT NULL,
	[Author] [nvarchar](150) NULL,
	[AuthorID] [int] NOT NULL,
	[SoftTypeID] [int] NULL,
	[SoftType] [nvarchar](100) NULL,
	[SoftCateID] [int] NULL,
	[SoftLanguage] [nvarchar](100) NULL,
	[CopyrightType] [nvarchar](100) NULL,
	[SoftSize] [int] NOT NULL,
	[SoftLevel] [nvarchar](255) NULL,
	[SoftPoint] [decimal](8, 2) NOT NULL,
	[SoftMoney] [decimal](8, 2) NOT NULL,
	[Stars] [int] NOT NULL,
	[Hits] [int] NOT NULL,
	[DayHits] [int] NOT NULL,
	[WeekHits] [int] NOT NULL,
	[MonthHits] [int] NOT NULL,
	[OnTop] [bit] NOT NULL,
	[Elite] [bit] NOT NULL,
	[Passed] [bit] NOT NULL,
	[IsAward] [int] NOT NULL,
	[IsSchool] [int] NOT NULL,
	[IsSupply] [int] NULL,
	[IsBoutique] [int] NULL,
	[IncludePic] [int] NULL,
	[PicUrl] [nvarchar](255) NULL,
	[Intro] [ntext] NULL,
	[FileAddress] [nvarchar](255) NOT NULL,
	[BackPoint] [int] NOT NULL,
	[BackPointRate] [int] NOT NULL,
	[BackMoney] [int] NOT NULL,
	[BackMoneyRate] [int] NOT NULL,
	[UserID] [int] NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Censor] [nvarchar](50) NULL,
	[CensorTime] [smalldatetime] NULL,
	[UpdateTime] [smalldatetime] NOT NULL,
	[AddTime] [smalldatetime] NOT NULL,
	[LastHitTime] [smalldatetime] NOT NULL,
	[GoodCount] [int] NULL,
	[PoorCount] [int] NULL,
	[IsAnalyze] [int] NULL,
	[SourceID] [int] NULL,
	[IsRecommend] [int] NULL,
	[IsCustom] [int] NULL,
	[AppState] [int] NULL,
	[ServiceSource] [int] NULL,
	[IsSelfCommand] [int] NULL,
	[CollectType] [int] NULL,
	[SoftFormat] [int] NULL,
	[IsAnswer] [int] NULL,
 CONSTRAINT [PK_Cl_Soft] PRIMARY KEY NONCLUSTERED 
(
	[SoftID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_InfoGuid]  DEFAULT (newid()) FOR [InfoGuid]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_CollectID]  DEFAULT ((0)) FOR [CollectID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_ChannelID]  DEFAULT ((0)) FOR [ChannelID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_ClassID]  DEFAULT ((0)) FOR [ClassID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_ChapterID]  DEFAULT ((0)) FOR [ChapterID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_NodeID]  DEFAULT ((0)) FOR [NodeID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_WholeID]  DEFAULT ((0)) FOR [WholeID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SpecialID]  DEFAULT ((0)) FOR [SpecialID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_FeatureID]  DEFAULT ((0)) FOR [FeatureID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_DepartmentID]  DEFAULT ((0)) FOR [DepartmentID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_GradeID]  DEFAULT ((0)) FOR [GradeID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_FontType]  DEFAULT ((0)) FOR [FontType]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_New_VersionID]  DEFAULT ((0)) FOR [VersionID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_AreaID]  DEFAULT ((0)) FOR [AreaID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_AuthorID]  DEFAULT ((0)) FOR [AuthorID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SoftTypeID]  DEFAULT ((0)) FOR [SoftTypeID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SoftCateID]  DEFAULT ((0)) FOR [SoftCateID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SoftSize]  DEFAULT ((0)) FOR [SoftSize]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SoftPoint]  DEFAULT ((0)) FOR [SoftPoint]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_SoftMoney]  DEFAULT ((0)) FOR [SoftMoney]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_Stars]  DEFAULT ((0)) FOR [Stars]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_Hits]  DEFAULT ((0)) FOR [Hits]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_DayHits]  DEFAULT ((0)) FOR [DayHits]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_WeekHits]  DEFAULT ((0)) FOR [WeekHits]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_MonthHits]  DEFAULT ((0)) FOR [MonthHits]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_OnTop]  DEFAULT ((0)) FOR [OnTop]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_Elite]  DEFAULT ((0)) FOR [Elite]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_Passed]  DEFAULT ((0)) FOR [Passed]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsAward]  DEFAULT ((0)) FOR [IsAward]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsSchool]  DEFAULT ((0)) FOR [IsSchool]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsSupply]  DEFAULT ((0)) FOR [IsSupply]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsBoutique]  DEFAULT ((0)) FOR [IsBoutique]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IncludePic]  DEFAULT ((0)) FOR [IncludePic]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_BackPoint]  DEFAULT ((0)) FOR [BackPoint]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_BackPointRate]  DEFAULT ((0)) FOR [BackPointRate]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_BackMoney]  DEFAULT ((0)) FOR [BackMoney]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_BackMoneyRate]  DEFAULT ((0)) FOR [BackMoneyRate]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_UserID]  DEFAULT ((0)) FOR [UserID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_CensorTime]  DEFAULT (getdate()) FOR [CensorTime]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_UpdateTime]  DEFAULT (getdate()) FOR [UpdateTime]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_AddTime]  DEFAULT (getdate()) FOR [AddTime]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_LastHitTime]  DEFAULT (getdate()) FOR [LastHitTime]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_GoodCount]  DEFAULT ((0)) FOR [GoodCount]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_PoorCount]  DEFAULT ((0)) FOR [PoorCount]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsAnalyze]  DEFAULT ((0)) FOR [IsAnalyze]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF__Cl_Soft__SourceI__61A803EE]  DEFAULT ((1)) FOR [SourceID]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  DEFAULT ((0)) FOR [IsRecommend]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  DEFAULT ((0)) FOR [IsCustom]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_ServiceSource]  DEFAULT ((0)) FOR [ServiceSource]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_Cl_Soft_IsSelfCommand]  DEFAULT ((0)) FOR [IsSelfCommand]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  CONSTRAINT [DF_cl_soft_CollectType]  DEFAULT ((0)) FOR [CollectType]
GO

ALTER TABLE [dbo].[Cl_Soft] ADD  DEFAULT ((0)) FOR [IsAnswer]
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'CollectID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ѧ��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'ChannelID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'ClassID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'ChapterID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'NodeID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�׾�ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'WholeID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ר��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SpecialID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ר��ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'FeatureID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ѧ��ID(0=����,1=Сѧ,2=����,3=����,4=��ѧ)' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'DepartmentID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�꼶ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'GradeID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ǰ׺' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Prefixion'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������ɫ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'FontColor'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����ʽ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'FontType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�汾ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'VersionID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϰ汾' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftVersion'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ؼ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Keyword'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'AreaID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ԴѧУ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Author'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'ѧУID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'AuthorID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftTypeID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftCateID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftLanguage'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'CopyrightType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϴ�С' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftSize'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����Ȩ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftLevel'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϵ���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftPoint'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϴ�ֵ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftMoney'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ȼ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Stars'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Hits'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'DayHits'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'WeekHits'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'MonthHits'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�̶�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'OnTop'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƽ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Elite'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ͨ��=1' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Passed'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�߼�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsAward'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��ʾ��Уͨ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsSchool'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ع�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsSupply'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ�Ʒ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsBoutique'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��������ͼ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IncludePic'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ͼURL' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'PicUrl'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Intro'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϵ�ַ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'FileAddress'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ص���' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'BackPoint'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ص�������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'BackPointRate'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ش�ֵ' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'BackMoney'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ش�ֵ����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'BackMoneyRate'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ϴ��û�ID' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'UserID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ϴ��û�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'UserName'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���վ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'Censor'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'CensorTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'UpdateTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�ϴ�ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'AddTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�����ʱ��' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'LastHitTime'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'GoodCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'PoorCount'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ��н�����0=�ޣ�1=�н�����' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsAnalyze'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'��Դ��1=ѧ������2=��ǣ�3=���ˣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SourceID'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���״̬��2=������3=������4=����ˣ�7=���ٲã�6=�������ˣ�8=��������ˣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'AppState'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������ͣ�1=�����Ƽ���2=�����ƣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'ServiceSource'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ����ƣ�1��ѧ�������ƣ�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsSelfCommand'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�������ͣ�1=��ͨ������2=��������' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'CollectType'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'���ϸ�ʽ��1=ͼƬ�棻2=�ĵ��棩' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'SoftFormat'
GO

EXEC sys.sp_addextendedproperty @name=N'MS_Description', @value=N'�Ƿ��д𰸣�0:�޴𰸣�1:�д𰸣�' , @level0type=N'SCHEMA',@level0name=N'dbo', @level1type=N'TABLE',@level1name=N'Cl_Soft', @level2type=N'COLUMN',@level2name=N'IsAnswer'
GO


